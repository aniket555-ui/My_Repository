package io.github.subhamtyagi.ocr.spinner;

/**
 * Created by Md Farhan Raja on 2/23/2017.
 */

public interface OnSpinnerItemClick {
    public void onClick(String item, int position);
}
